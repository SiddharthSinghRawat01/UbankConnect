const mysqlcon = require('../../../config/db_connection');

const payoutMethods = {
    searchByOrderId: async (req, res) => {
        let user = req.user;
        try {
            const { uniqueid } = req.body;
            let sql = 'SELECT * FROM tbl_icici_payout_transaction_response_details WHERE uniqueid = ? AND users_id = ?';
            mysqlcon(sql, [uniqueid, user.id], async (err, result) => {
                // if (err) {throw err}
                if (result.length === 0) {
                    res.status(201).json({ message: 'No record found.' });
                } else {
                    res.status(200).json({
                        message: 'Report for order id ' + uniqueid + ' is ',
                        data: result
                    })
                }
            })
        } catch (error) {
            res.status(201).json({ status: false, message: 'Some error occured', data: [] });
        } finally {
            console.log("Execution completed.");
        }
    },

    today: async (req, res) => {
        let user = req.user;
        let limit = 10;
        try {
            const { todaysDate } = req.body;
            let sql = 'SELECT COUNT(*) AS Total FROM tbl_icici_payout_transaction_response_details WHERE DATE(created_on) = ? AND users_id = ?';
            mysqlcon(sql, [todaysDate, user.id], async (err, result) => {
                console.log(result)
                let total = result[0].Total
                let numOfPages = Math.ceil(total / limit)
                let page = req.body.page ? Number(req.body.page) : 1
                let start = ((page * limit) - (limit))
                let sql1 = 'SELECT * FROM tbl_icici_payout_transaction_response_details WHERE DATE(created_on) = ? AND users_id = ? LIMIT ?,?'
                mysqlcon(sql1, [todaysDate, user.id, start, limit], async (err, result) => {
                    if (result.length === 0) {
                        res.status(201).json({ message: 'No record found.' });
                    } else {
                        res.status(200).json({
                            message: 'Report for Date ' + todaysDate + ' is ',
                            currPage: page,
                            message1: 'Showing ' + result.length + ' out of ' + total + ' results',
                            totalPage: numOfPages,
                            data: result
                        })
                    }
                })
            })
        } catch (error) {
            res.status(201).json({ status: false, message: 'Some error occured', data: [] });
        } finally {
            console.log("Execution completed.");
        }
    },

    yesterday: async (req, res) => {
        let user = req.user;
        let limit = 10;
        try {
            const { yesterdaysDate } = req.body;
            let sql = 'SELECT COUNT(*) AS Total FROM tbl_icici_payout_transaction_response_details WHERE DATE(created_on) = ? AND users_id = ?';
            mysqlcon(sql, [yesterdaysDate, user.id], async (err, result) => {
                let total = result[0].Total
                let numOfPages = Math.ceil(total / limit)
                let page = req.body.page ? Number(req.body.page) : 1
                let start = ((page * limit) - (limit))
                let sql1 = 'SELECT * FROM tbl_icici_payout_transaction_response_details WHERE DATE(created_on) = ? AND users_id = ? LIMIT ?,?'
                mysqlcon(sql1, [yesterdaysDate, user.id, start, limit], async (err, result) => {
                    if (result.length === 0) {
                        res.status(201).json({ message: 'No record found.' });
                    } else {
                        res.status(200).json({
                            message: 'Report for Date ' + yesterdaysDate + ' is ',
                            currPage: page,
                            message1: 'Showing ' + result.length + ' out of ' + total + ' results',
                            totalPage: numOfPages,
                            data: result
                        })
                    }
                })
            })
        } catch (error) {
            res.status(201).json({ status: false, message: 'Some error occured', data: [] });
        } finally {
            console.log("Execution completed.");
        }
    },

    customDate: async (req, res) => {
        let user = req.user;
        const { from, to } = req.body;
        let limit = 10;
        try {
            let sql = 'SELECT COUNT(*) AS Total FROM tbl_icici_payout_transaction_response_details WHERE DATE(created_on) >= ? AND DATE(created_on) <= ? AND users_id = ?'
            mysqlcon(sql, [from, to, user.id], async (err, result) => {
                let total = result[0].Total
                let numOfPages = Math.ceil(total / limit)
                let page = req.body.page ? Number(req.body.page) : 1
                let start = ((page * limit) - (limit))
                let sql1 = 'SELECT * FROM tbl_icici_payout_transaction_response_details WHERE DATE(created_on) >= ? AND DATE(created_on) <= ? AND users_id = ? LIMIT ?,?'
                mysqlcon(sql1, [from, to, user.id, start, limit], async (err, result) => {
                    if (result.length === 0) {
                        res.status(201).json({ message: 'No record found.' });
                    } else {
                        res.status(200).json({
                            message: 'Report from ' + from + " to " + to + ' is ',
                            currPage: page,
                            message1: 'Showing ' + limit + ' out of ' + total + ' results',
                            totalPage: numOfPages,
                            data: result
                        })
                    }
                })
            })
        } catch (error) {
            res.status(201).json({ status: false, message: 'Some error occured', data: [] });
        } finally {
            console.log("Execution completed.");
        }
    },

    success: async (req, res) => {
        let user = req.user;
        try {
            let sql = 'SELECT  SUM(amount) AS amount FROM tbl_icici_payout_transaction_response_details WHERE  users_id = ? AND status = ?';
            mysqlcon(sql, [user.id, 'SUCCESS'], async (err, result) => {
                // if (err) {throw err}
                if (result.length === 0) {
                    res.status(201).json({
                        message: 'Total Success amount of ' + user.name + ' is 0.',
                        data: 0
                    });
                } else {
                    res.status(200).json({
                        message: 'Total Success amount of ' + user.name + ' is ' + result[0].amount,
                        data: result
                    })
                }
            })
        } catch (error) {
            res.status(201).json({ status: false, message: 'Some error occured', data: [] });
        } finally {
            console.log("Execution completed.");
        }
    },

    declined: async (req, res) => {
        let user = req.user;
        try {
            let sql = 'SELECT  SUM(amount) AS amount FROM tbl_icici_payout_transaction_response_details WHERE users_id = ? AND status = ?'
            mysqlcon(sql, [user.id, 'DECLINED'], async (err, result) => {
                // if (err) {throw err}
                if (result.length === 0) {
                    res.status(201).json({
                        message: 'Total Declined amount of ' + user.name + ' is 0.',
                        data: 0
                    });
                } else {
                    res.status(200).json({
                        message: 'Total Declined amount of ' + user.name + ' is ' + result[0].amount,
                        data: result
                    })
                }
            })
        } catch (error) {
            res.status(201).json({ status: false, message: 'Some error occured', data: [] });
        } finally {
            console.log("Execution completed.");
        }
    },

    pending: async (req, res) => {
        let user = req.user;
        try {
            let sql = 'SELECT  SUM(amount) AS amount FROM tbl_icici_payout_transaction_response_details WHERE users_id = ? AND status = ?'
            mysqlcon(sql, [user.id, 'PENDING'], async (err, result) => {
                // if (err) {throw err}
                if (result.length === 0) {
                    res.status(201).json({
                        message: 'Total Pending amount of ' + user.name + ' is 0.',
                        data: 0
                    });
                } else {
                    res.status(200).json({
                        message: 'Total Pending amount of ' + user.name + ' is ' + result[0].amount,
                        data: result
                    })
                }
            })
        } catch (error) {
            res.status(201).json({ status: false, message: 'Some error occured', data: [] });
        } finally {
            console.log("Execution completed.");
        }
    },

    total: async (req, res) => {
        let user = req.user;
        res.status(200).json({
            message: 'Total amount of ' + user.name + ' is ' + user.wallet,
            data: user.wallet
        });
    },

    viewDetails: async (req, res) => {
        let user = req.user;
        const { uniqueid } = req.body;
        try {
            let sql = 'SELECT * FROM tbl_icici_payout_transaction_response_details WHERE uniqueid = ? AND users_id = ?';
            mysqlcon(sql, [uniqueid, user.id], async (err, result) => {
                res.status(200).json({
                    message: 'Transection details are : ',
                    data: result
                })
            })
        } catch (error) {
            res.status(201).json({ status: false, message: 'Some error occured', data: [] });
        } finally {
            console.log("Execution completed.");
        }
    },

    downloadReport: async (req, res) => {
        let user = req.user;
        const { uniqueid } = req.body
        try {
            if (uniqueid != undefined) {
                let sql = 'SELECT uniqueid, created_on, utrnumber, creditacc, bank_name, amount, status FROM tbl_icici_payout_transaction_response_details WHERE uniqueid in (?) AND users_id = ?';
                mysqlcon(sql, [uniqueid, user.id], async (err, result) => {
                    if (result.length === 0) {
                        res.status(201).json({ message: 'No record found.' });
                    } else {
                        res.status(200).json({
                            message: 'Transection details are : ',
                            data: result
                        })
                    }
                })
            }
            else {
                let sql = 'SELECT uniqueid, created_on, utrnumber, creditacc, bank_name, amount, status FROM tbl_icici_payout_transaction_response_details WHERE users_id = ?';
                mysqlcon(sql, [user.id], async (err, result) => {
                    if (result.length === 0) {
                        res.status(201).json({ message: 'No record found.' });
                    } else {
                        res.status(200).json({
                            message: 'Transection details are : ',
                            data: result
                        })
                    }
                })
            }
        } catch (error) {
            res.status(201).json({ status: false, message: 'Some error occured', data: [] });
        } finally {
            console.log("Execution completed.");
        }

    }

}



module.exports = payoutMethods

